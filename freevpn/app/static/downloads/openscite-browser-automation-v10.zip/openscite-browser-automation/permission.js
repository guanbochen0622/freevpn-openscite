
(async()=>{
  const q=new URLSearchParams(location.search), t=q.get("token")||"", key="permission:"+t;
  const d=(await chrome.storage.session.get(key))[key];
  if(!d){document.body.textContent="權限請求已過期。";return}
  document.getElementById("origin").textContent=d.displayOrigin||d.originPattern;
  async function finish(allow){
    if(allow){
      const granted=await chrome.permissions.request({origins:[d.originPattern]});
      if(!granted)return;
    }
    await chrome.runtime.sendMessage({type:"PERMISSION_DECISION",token:t,allow});
    close();
  }
  document.getElementById("yes").onclick=()=>finish(true);
  document.getElementById("no").onclick=()=>finish(false);
})();
