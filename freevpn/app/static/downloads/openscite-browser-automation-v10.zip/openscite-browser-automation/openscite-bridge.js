
(() => {
  const SOURCE_WEB = "openscite-web";
  const SOURCE_EXT = "openscite-extension";
  const VERSION = chrome.runtime.getManifest().version;
  const pageNonce = crypto.randomUUID();

  function allowedPage() {
    const u = location.href;
    return /^https:\/\/mo7yw4ng\.github\.io\/openscite\//i.test(u) ||
           /^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?\//i.test(u) ||
           /^file:\/\//i.test(u);
  }
  if (!allowedPage()) return;

  function sendToPage(type, payload = {}) {
    window.postMessage({
      source: SOURCE_EXT,
      type,
      payload,
      version: VERSION,
      nonce: pageNonce
    }, "*");
  }

  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.source !== SOURCE_WEB) return;
    if (e.data.nonce && e.data.nonce !== pageNonce) return;

    if (e.data.type === "OPENSCITE_EXTENSION_PING") {
      sendToPage("OPENSCITE_EXTENSION_PONG", { nonce: pageNonce });
      return;
    }

    if (e.data.type === "OPENSCITE_AUTOMATE_ACCESS") {
      try {
        const p = e.data.payload || {};
        if (!Number.isInteger(p.paperIndex)) throw new Error("Invalid paper index.");
        const resp = await chrome.runtime.sendMessage({
          type: "START_ACCESS_JOB",
          payload: {
            paperIndex: p.paperIndex,
            title: String(p.title || "").slice(0, 500),
            doi: String(p.doi || "").slice(0, 300),
            url: String(p.url || "").slice(0, 2000)
          }
        });
        if (resp?.error) sendToPage("OPENSCITE_AUTOMATION_STATUS", { state: "error", message: resp.error });
      } catch (err) {
        sendToPage("OPENSCITE_AUTOMATION_STATUS", { state: "error", message: String(err?.message || err) });
      }
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "JOB_STATUS") sendToPage("OPENSCITE_AUTOMATION_STATUS", msg.payload || {});
  });

  sendToPage("OPENSCITE_EXTENSION_PONG", { nonce: pageNonce });
})();
