# OpenScite Browser Automation v10

v10 加入高相容 Network inspection（網路監看）模式。

## 取得策略
1. 一般 DOM / metadata / viewer / blob 偵測。
2. 若頁面使用短效 token、signed URL、隱藏 viewer request，使用 Chrome DevTools Network 監看「目前這一個 publisher tab」。
3. 只收集看起來是 PDF 的 response URL / MIME metadata。
4. Extension 自己的確認視窗列出候選來源。
5. 使用者選取並允許後才下載。
6. 工作完成、取消或 publisher tab 關閉後：
   - `chrome.debugger.detach`
   - 移除臨時 publisher host permission
   - 清除 session confirmation token

## 明確不做
- 不破解 DRM。
- 不繞過登入或 paywall。
- 不提取或保存帳號密碼。
- 不匯出 cookies / Authorization headers。
- 不重放非 PDF 的 authenticated API request。
- 不對非本次 publisher tab 啟用 Network inspection。

## 風險
Chrome 的 `debugger` permission 很強。因此 v10 只在 OpenScite 建立的單篇論文 job 中使用，而且 UI 會明確告知。若安全優先，可繼續使用 v9。
