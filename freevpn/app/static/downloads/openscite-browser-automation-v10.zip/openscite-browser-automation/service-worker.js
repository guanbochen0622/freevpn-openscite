
const jobs=new Map();
let opensciteTabId=null;

const clean=(s,n=800)=>String(s||"").slice(0,n);
const token=()=>crypto.randomUUID();
function safeName(s){return String(s).replace(/[\\/:*?"<>|]+/g," ").replace(/\s+/g," ").trim().slice(0,120)||"paper"}
function asUrl(raw){try{return new URL(raw)}catch{return null}}
function httpUrl(raw){const u=asUrl(raw);return !!u&&(u.protocol==="https:"||u.protocol==="http:")}
function originPattern(raw){const u=asUrl(raw);if(!u||!/^https?:$/.test(u.protocol))return null;return `${u.protocol}//${u.host}/*`}
async function siteStatus(payload){if(opensciteTabId==null)return;try{await chrome.tabs.sendMessage(opensciteTabId,{type:"JOB_STATUS",payload})}catch{}}

async function attachDebugger(job){
  if(job.debugAttached)return true;
  try{
    await chrome.debugger.attach({tabId:job.tabId},"1.3");
    await chrome.debugger.sendCommand({tabId:job.tabId},"Network.enable",{maxTotalBufferSize:20000000,maxResourceBufferSize:5000000});
    job.debugAttached=true;
    return true;
  }catch(e){
    await siteStatus({state:"debugger-error",paperIndex:job.paperIndex,message:String(e)});
    return false;
  }
}
async function detachDebugger(job){
  if(!job?.debugAttached)return;
  try{await chrome.debugger.detach({tabId:job.tabId})}catch{}
  job.debugAttached=false;
}
async function releaseJob(tabId){
  const job=jobs.get(tabId);if(!job)return;
  await detachDebugger(job);
  for(const p of job.temporaryOrigins||[]){try{await chrome.permissions.remove({origins:[p]})}catch{}}
  if(job.permissionToken)try{await chrome.storage.session.remove("permission:"+job.permissionToken)}catch{}
  if(job.confirmToken)try{await chrome.storage.session.remove("confirm:"+job.confirmToken)}catch{}
  jobs.delete(tabId);
}
async function askOriginPermission(job,pageUrl){
  const p=originPattern(pageUrl);if(!p)throw new Error("Unsupported publisher origin.");
  if(await chrome.permissions.contains({origins:[p]}))return true;
  const t=token();job.permissionToken=t;
  await chrome.storage.session.set({["permission:"+t]:{tabId:job.tabId,paperIndex:job.paperIndex,title:job.title,originPattern:p,displayOrigin:new URL(pageUrl).origin}});
  await chrome.windows.create({url:chrome.runtime.getURL("permission.html")+"?token="+encodeURIComponent(t),type:"popup",width:600,height:500,focused:true});
  await siteStatus({state:"permission-required",paperIndex:job.paperIndex,origin:new URL(pageUrl).origin});
  return false;
}

async function scanDom(tabId){
  const out=await chrome.scripting.executeScript({
    target:{tabId},
    func:async()=>{
      const abs=(x)=>{try{return new URL(x,location.href).href}catch{return ""}};
      const items=[];
      const add=(url,text,kind,score)=>{url=abs(url);if(!url||!/^(https?:|blob:)/i.test(url))return;items.push({url,text:String(text||"").trim().replace(/\s+/g," ").slice(0,300),kind,score})};

      for(const m of document.querySelectorAll('meta[name="citation_pdf_url"],meta[property="citation_pdf_url"]')) add(m.content||"","citation_pdf_url","metadata",18);
      for(const el of document.querySelectorAll('iframe[src],embed[src],object[data]')){
        const raw=el.getAttribute("src")||el.getAttribute("data")||"";
        if(/\.pdf(?:$|[?#])|\/pdf(?:\/|$|\?)|blob:/i.test(raw))add(raw,el.title||"Embedded PDF","embedded",14);
        try{const u=new URL(raw,location.href);const f=u.searchParams.get("file");if(f)add(decodeURIComponent(f),"Viewer file","viewer-file",15)}catch{}
      }
      for(const a of document.querySelectorAll("a[href]")){
        const href=a.getAttribute("href")||"";
        const txt=(a.innerText||a.textContent||"")+" "+(a.getAttribute("aria-label")||"")+" "+(a.title||"");
        const b=(txt+" "+href).toLowerCase();let score=0;
        if(/\.pdf(?:$|[?#])/i.test(href))score+=11;
        if(/\/pdf(?:\/|$|\?)/i.test(href))score+=8;
        if(/\b(download|view|open)\s+(full\s*text\s*)?pdf\b/i.test(b))score+=9;
        if(/\bpdf\b/i.test(b))score+=4;
        if(/\b(full text|download)\b/i.test(b))score+=2;
        if(/supplement|supporting information|appendix|graphical abstract/i.test(b))score-=9;
        if(score>=5)add(href,txt,"link",score);
      }
      try{
        for(const r of performance.getEntriesByType("resource")){
          const n=r.name||"";
          if(/\.pdf(?:$|[?#])|\/pdf(?:\/|$|\?)/i.test(n))add(n,"Loaded PDF resource","performance-resource",13);
        }
      }catch{}
      if(/\.pdf(?:$|[?#])|\/pdf(?:\/|$|\?)/i.test(location.href))add(location.href,document.title||"Current PDF","current-page",20);

      for(const x of items){
        if(x.url.startsWith("blob:")){
          try{
            const r=await fetch(x.url);const b=await r.blob();
            x.blobType=b.type||"";x.blobSize=b.size||0;
            if(/pdf/i.test(b.type))x.score+=7;else if(b.size<5000)x.score-=12;
          }catch{x.score-=5}
        }
      }
      const seen=new Set(),res=[];
      items.sort((a,b)=>b.score-a.score);
      for(const x of items){if(x.score<5||seen.has(x.url))continue;seen.add(x.url);x.risk=x.url.startsWith("blob:")?"special":"normal";res.push(x);if(res.length>=12)break}
      return {pageUrl:location.href,pageTitle:document.title,candidates:res};
    }
  });
  return out?.[0]?.result||{pageUrl:"",candidates:[]};
}
function looksPdfResponse(p){
  const url=p.response?.url||"";
  const mime=(p.response?.mimeType||"").toLowerCase();
  const headers=p.response?.headers||{};
  const ct=String(headers["content-type"]||headers["Content-Type"]||"").toLowerCase();
  const cd=String(headers["content-disposition"]||headers["Content-Disposition"]||"").toLowerCase();
  return mime.includes("pdf")||ct.includes("application/pdf")||/filename=.*\.pdf/i.test(cd)||/\.pdf(?:$|[?#])|\/pdf(?:\/|$|\?)/i.test(url);
}
async function showConfirm(job,candidates,pageUrl){
  const t=token();job.confirmToken=t;
  const safe=candidates.slice(0,16).map((x,i)=>({...x,id:i}));
  await chrome.storage.session.set({["confirm:"+t]:{tabId:job.tabId,paperIndex:job.paperIndex,title:job.title,pageUrl,candidates:safe}});
  await chrome.windows.create({url:chrome.runtime.getURL("confirm.html")+"?token="+encodeURIComponent(t),type:"popup",width:680,height:700,focused:true});
  await siteStatus({state:"awaiting-confirmation",paperIndex:job.paperIndex});
}
async function continueJob(tabId){
  const job=jobs.get(tabId);if(!job)return;
  const tab=await chrome.tabs.get(tabId);
  if(!tab.url||!/^https?:/i.test(tab.url)){await siteStatus({state:"error",paperIndex:job.paperIndex,message:"Unsupported publisher page."});return}
  if(!(await chrome.permissions.contains({origins:[originPattern(tab.url)]}))){await askOriginPermission(job,tab.url);return}
  await attachDebugger(job);
  await siteStatus({state:"scanning",paperIndex:job.paperIndex});
  const dom=await scanDom(tabId);
  const merged=[...(dom.candidates||[]),...(job.networkCandidates||[])];
  const seen=new Set(),uniq=[];
  for(const x of merged.sort((a,b)=>(b.score||0)-(a.score||0))){
    if(!x.url||seen.has(x.url))continue;seen.add(x.url);uniq.push(x);if(uniq.length>=16)break
  }
  if(uniq.length)await showConfirm(job,uniq,dom.pageUrl);
  else await siteStatus({state:"no-pdf",paperIndex:job.paperIndex});
}

chrome.debugger.onEvent.addListener(async(source,method,params)=>{
  const job=jobs.get(source.tabId);if(!job||!job.debugAttached)return;
  if(method==="Network.responseReceived"&&looksPdfResponse(params)){
    const url=params.response?.url||"";
    if(!/^https?:/i.test(url))return;
    const mime=params.response?.mimeType||"";
    const entry={url,text:"Network PDF response",kind:"devtools-network",score:22,risk:"network",mime};
    job.networkCandidates=job.networkCandidates||[];
    if(!job.networkCandidates.some(x=>x.url===url))job.networkCandidates.push(entry);
    await siteStatus({state:"network-pdf-found",paperIndex:job.paperIndex});
  }
});
chrome.debugger.onDetach.addListener(source=>{const job=jobs.get(source.tabId);if(job)job.debugAttached=false});

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  (async()=>{
    try{
      if(msg?.type==="START_ACCESS_JOB"){
        opensciteTabId=sender.tab?.id??opensciteTabId;
        const p=msg.payload||{};
        if(!Number.isInteger(p.paperIndex)||!httpUrl(p.url))throw new Error("Invalid OpenScite request.");
        const tab=await chrome.tabs.create({url:p.url,active:true});
        jobs.set(tab.id,{tabId:tab.id,paperIndex:p.paperIndex,title:clean(p.title,500),doi:clean(p.doi,300),startUrl:p.url,createdAt:Date.now(),temporaryOrigins:[],networkCandidates:[],debugAttached:false});
        await siteStatus({state:"opening",paperIndex:p.paperIndex});
        sendResponse({ok:true,tabId:tab.id});return
      }
      if(msg?.type==="PERMISSION_DECISION"){
        const key="permission:"+String(msg.token||"");const stored=(await chrome.storage.session.get(key))[key];
        if(!stored)throw new Error("Permission expired.");
        const job=jobs.get(stored.tabId);if(!job||job.permissionToken!==msg.token)throw new Error("Permission/job mismatch.");
        await chrome.storage.session.remove(key);job.permissionToken=null;
        if(!msg.allow){await siteStatus({state:"cancelled",paperIndex:job.paperIndex});await releaseJob(job.tabId);sendResponse({ok:true});return}
        const granted=await chrome.permissions.contains({origins:[stored.originPattern]});
        if(!granted)throw new Error("Publisher permission not granted.");
        job.temporaryOrigins.push(stored.originPattern);
        await continueJob(job.tabId);sendResponse({ok:true});return
      }
      if(msg?.type==="RESCAN_JOB"){
        const job=jobs.get(Number(msg.tabId));if(!job)throw new Error("No active job.");
        await continueJob(job.tabId);sendResponse({ok:true});return
      }
      if(msg?.type==="CONFIRM_DOWNLOAD"){
        const key="confirm:"+String(msg.token||"");const stored=(await chrome.storage.session.get(key))[key];
        if(!stored)throw new Error("Confirmation expired.");
        const job=jobs.get(stored.tabId);if(!job||job.confirmToken!==msg.token)throw new Error("Confirmation/job mismatch.");
        await chrome.storage.session.remove(key);job.confirmToken=null;
        if(!msg.allow){await siteStatus({state:"cancelled",paperIndex:job.paperIndex});await releaseJob(job.tabId);sendResponse({ok:true});return}
        const c=stored.candidates?.[Number(msg.index)];if(!c?.url)throw new Error("Invalid PDF candidate.");
        let downloadId=null;
        if(c.url.startsWith("blob:")){
          const res=await chrome.scripting.executeScript({target:{tabId:job.tabId},args:[c.url,safeName(job.title)+".pdf"],func:async(url,name)=>{
            try{const r=await fetch(url);const b=await r.blob();if(!/pdf/i.test(b.type)&&b.size<5000)return{ok:false,reason:"Blob is not PDF-like."};const a=document.createElement("a");a.href=url;a.download=name;a.style.display="none";document.documentElement.appendChild(a);a.click();a.remove();return{ok:true,size:b.size,type:b.type}}catch(e){return{ok:false,reason:String(e)}}
          }});
          const rr=res?.[0]?.result;if(!rr?.ok)throw new Error(rr?.reason||"Blob download failed.");
          await siteStatus({state:"download-started",paperIndex:job.paperIndex,mode:"blob",bytes:rr.size});
        }else{
          if(!httpUrl(c.url))throw new Error("Unsupported candidate URL.");
          downloadId=await chrome.downloads.download({url:c.url,filename:`OpenScite/${safeName(job.title)}.pdf`,saveAs:true});
          await siteStatus({state:"download-started",paperIndex:job.paperIndex,downloadId,mode:c.kind||"http"});
        }
        await releaseJob(job.tabId);sendResponse({ok:true,downloadId});return
      }
    }catch(e){await siteStatus({state:"error",message:String(e?.message||e)});sendResponse({error:String(e?.message||e)})}
  })();
  return true;
});
chrome.tabs.onUpdated.addListener(async(tabId,info)=>{if(info.status==="complete"&&jobs.has(tabId)){try{await continueJob(tabId)}catch{}}});
chrome.tabs.onRemoved.addListener(tabId=>releaseJob(tabId));
