
(async()=>{
 const q=new URLSearchParams(location.search),t=q.get("token")||"",key="confirm:"+t;
 const d=(await chrome.storage.session.get(key))[key];
 if(!d){document.body.textContent="確認工作已過期。";return}
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 document.getElementById("title").textContent=d.title||"";
 const root=document.getElementById("opts");
 (d.candidates||[]).forEach((x,i)=>{
   const l=document.createElement("label");l.className="opt";
   let cls=x.risk==="special"?"special":x.risk==="cross-origin"?"cross":"";
   let risk=x.kind==="devtools-network"?"Network 捕捉":x.risk==="special"?"特殊 viewer/blob":x.risk==="cross-origin"?"跨網域 CDN":"一般直接 PDF";
   l.innerHTML=`<input type="radio" name="pdf" value="${i}" ${i===0?"checked":""}><span><b>${esc(x.text||"PDF")}</b><div class="u">${esc(x.url)}</div><div class="meta"><span class="pill ${cls}">${esc(risk)}</span><span class="pill">${esc(x.kind||"link")}</span>${x.blobType?`<span class="pill">${esc(x.blobType)}</span>`:""}</div></span>`;
   root.appendChild(l);
 });
 async function done(allow){
   const i=Number(document.querySelector('input[name="pdf"]:checked')?.value||0);
   await chrome.runtime.sendMessage({type:"CONFIRM_DOWNLOAD",token:t,allow,index:i});close();
 }
 document.getElementById("cancel").onclick=()=>done(false);
 document.getElementById("allow").onclick=()=>done(true);
})();
